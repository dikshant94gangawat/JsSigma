import React, { createContext, useContext, useReducer } from 'react'

const EmailContext = createContext()

const initialState = {
  pdfFile: null,
  pdfPages: [],
  emailTemplate: {
    width: 600,
    backgroundColor: '#ffffff',
    elements: []
  },
  selectedElement: null,
  previewMode: 'desktop',
  isConverting: false,
  convertedHtml: '',
  cssInlined: false
}

function emailReducer(state, action) {
  switch (action.type) {
    case 'SET_PDF_FILE':
      return { ...state, pdfFile: action.payload }
    
    case 'SET_PDF_PAGES':
      return { ...state, pdfPages: action.payload }
    
    case 'SET_CONVERTING':
      return { ...state, isConverting: action.payload }
    
    case 'ADD_ELEMENT':
      return {
        ...state,
        emailTemplate: {
          ...state.emailTemplate,
          elements: [...state.emailTemplate.elements, action.payload]
        }
      }
    
    case 'UPDATE_ELEMENT':
      return {
        ...state,
        emailTemplate: {
          ...state.emailTemplate,
          elements: state.emailTemplate.elements.map(el =>
            el.id === action.payload.id ? { ...el, ...action.payload } : el
          )
        }
      }
    
    case 'REMOVE_ELEMENT':
      return {
        ...state,
        emailTemplate: {
          ...state.emailTemplate,
          elements: state.emailTemplate.elements.filter(el => el.id !== action.payload)
        },
        selectedElement: state.selectedElement === action.payload ? null : state.selectedElement
      }
    
    case 'SELECT_ELEMENT':
      return { ...state, selectedElement: action.payload }
    
    case 'UPDATE_TEMPLATE':
      return {
        ...state,
        emailTemplate: { ...state.emailTemplate, ...action.payload }
      }
    
    case 'SET_PREVIEW_MODE':
      return { ...state, previewMode: action.payload }
    
    case 'SET_CONVERTED_HTML':
      return { ...state, convertedHtml: action.payload }
    
    case 'SET_CSS_INLINED':
      return { ...state, cssInlined: action.payload }
    
    case 'RESET_TEMPLATE':
      return {
        ...state,
        emailTemplate: initialState.emailTemplate,
        selectedElement: null,
        convertedHtml: '',
        cssInlined: false
      }
    
    default:
      return state
  }
}

export function EmailProvider({ children }) {
  const [state, dispatch] = useReducer(emailReducer, initialState)

  const value = {
    ...state,
    dispatch
  }

  return (
    <EmailContext.Provider value={value}>
      {children}
    </EmailContext.Provider>
  )
}

export function useEmail() {
  const context = useContext(EmailContext)
  if (!context) {
    throw new Error('useEmail must be used within an EmailProvider')
  }
  return context
}
