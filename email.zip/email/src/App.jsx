import React, { useState } from 'react'
import Header from './components/Header'
import Sidebar from './components/Sidebar'
import MainCanvas from './components/MainCanvas'
import PropertiesPanel from './components/PropertiesPanel'
import PDFUploader from './components/PDFUploader'
import { EmailProvider } from './context/EmailContext'

function App() {
  const [activeTab, setActiveTab] = useState('upload')
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [propertiesOpen, setPropertiesOpen] = useState(true)

  return (
    <EmailProvider>
      <div className="min-h-screen bg-gray-50">
        <Header 
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          sidebarOpen={sidebarOpen}
          setSidebarOpen={setSidebarOpen}
          propertiesOpen={propertiesOpen}
          setPropertiesOpen={setPropertiesOpen}
        />
        
        <div className="flex h-[calc(100vh-64px)]">
          {sidebarOpen && (
            <Sidebar 
              activeTab={activeTab}
              setActiveTab={setActiveTab}
            />
          )}
          
          <div className="flex-1 flex">
            <MainCanvas 
              activeTab={activeTab}
              setActiveTab={setActiveTab}
            />
            
            {propertiesOpen && activeTab === 'builder' && (
              <PropertiesPanel />
            )}
          </div>
        </div>
      </div>
    </EmailProvider>
  )
}

export default App
