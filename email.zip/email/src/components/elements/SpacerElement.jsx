import React, { useState } from 'react'
import { Edit3, Trash2 } from 'lucide-react'

function SpacerElement({ element, isSelected, onClick, onUpdate }) {
  const [isEditing, setIsEditing] = useState(false)
  const [spacerHeight, setSpacerHeight] = useState(element.content.height || 20)

  const handleSave = () => {
    onUpdate({ 
      content: { height: spacerHeight },
      styles: {
        ...element.styles,
        height: `${spacerHeight}px`
      }
    })
    setIsEditing(false)
  }

  return (
    <div
      className={`relative group cursor-pointer transition-all duration-200 ${
        isSelected ? 'ring-2 ring-primary-500 ring-offset-2' : 'hover:ring-1 hover:ring-gray-300'
      }`}
      onClick={onClick}
    >
      {isEditing ? (
        <div className="space-y-3 p-3 border border-primary-300 rounded">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Height (pixels)
            </label>
            <input
              type="number"
              value={spacerHeight}
              onChange={(e) => setSpacerHeight(parseInt(e.target.value) || 0)}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-primary-500"
              min="0"
              max="200"
            />
          </div>

          <div className="flex space-x-2">
            <button
              onClick={handleSave}
              className="px-3 py-1 bg-primary-600 text-white text-sm rounded hover:bg-primary-700"
            >
              Save
            </button>
            <button
              onClick={() => {
                setSpacerHeight(element.content.height || 20)
                setIsEditing(false)
              }}
              className="px-3 py-1 bg-gray-300 text-gray-700 text-sm rounded hover:bg-gray-400"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <div
          className="w-full bg-gray-100 border-2 border-dashed border-gray-300 flex items-center justify-center"
          style={{
            ...element.styles,
            height: `${spacerHeight}px`,
            minHeight: '20px'
          }}
        >
          <span className="text-xs text-gray-500">
            {spacerHeight}px spacer
          </span>
        </div>
      )}

      {isSelected && !isEditing && (
        <div className="absolute -top-8 left-0 flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={(e) => {
              e.stopPropagation()
              setIsEditing(true)
            }}
            className="p-1 bg-white border border-gray-300 rounded shadow-sm hover:bg-gray-50"
            title="Edit spacer"
          >
            <Edit3 size={14} />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation()
              onUpdate({ deleted: true })
            }}
            className="p-1 bg-white border border-gray-300 rounded shadow-sm hover:bg-red-50 hover:border-red-300"
            title="Delete element"
          >
            <Trash2 size={14} />
          </button>
        </div>
      )}
    </div>
  )
}

export default SpacerElement
