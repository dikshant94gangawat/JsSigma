import React, { useState, useRef } from 'react'
import { Upload, FileText, AlertCircle, CheckCircle, Loader } from 'lucide-react'
import { useEmail } from '../context/EmailContext'

function PDFUploader() {
  const { dispatch, isConverting } = useEmail()
  const [uploadProgress, setUploadProgress] = useState(0)
  const [isDragActive, setIsDragActive] = useState(false)
  const fileInputRef = useRef(null)

  const handleFileSelect = async (file) => {
    if (!file) return

    if (file.type !== 'application/pdf') {
      alert('Please upload a PDF file')
      return
    }

    if (file.size > 10 * 1024 * 1024) { // 10MB limit
      alert('File size must be less than 10MB')
      return
    }

    dispatch({ type: 'SET_PDF_FILE', payload: file })
    dispatch({ type: 'SET_CONVERTING', payload: true })
    setUploadProgress(0)

    try {
      // Simulate upload progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval)
            return 90
          }
          return prev + 10
        })
      }, 200)

      // Convert PDF to HTML
      const formData = new FormData()
      formData.append('pdf', file)

      const response = await fetch('/api/convert-pdf', {
        method: 'POST',
        body: formData
      })

      if (!response.ok) {
        throw new Error('Failed to convert PDF')
      }

      const result = await response.json()
      
      clearInterval(progressInterval)
      setUploadProgress(100)

      dispatch({ type: 'SET_PDF_PAGES', payload: result.pages })
      dispatch({ type: 'SET_CONVERTED_HTML', payload: result.html })
      dispatch({ type: 'SET_CONVERTING', payload: false })

      alert('PDF converted successfully!')
      
      // Auto-switch to builder tab after successful conversion
      setTimeout(() => {
        window.dispatchEvent(new CustomEvent('switchTab', { detail: 'builder' }))
      }, 1000)

    } catch (error) {
      console.error('PDF conversion error:', error)
      dispatch({ type: 'SET_CONVERTING', payload: false })
      setUploadProgress(0)
      alert('Failed to convert PDF. Please try again.')
    }
  }

  const handleFileInputChange = (e) => {
    const file = e.target.files[0]
    handleFileSelect(file)
  }

  const handleDragOver = (e) => {
    e.preventDefault()
    setIsDragActive(true)
  }

  const handleDragLeave = (e) => {
    e.preventDefault()
    setIsDragActive(false)
  }

  const handleDrop = (e) => {
    e.preventDefault()
    setIsDragActive(false)
    const file = e.dataTransfer.files[0]
    handleFileSelect(file)
  }

  return (
    <div className="flex-1 flex items-center justify-center p-8">
      <div className="max-w-2xl w-full">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Convert PDF to Email Template
          </h2>
          <p className="text-lg text-gray-600">
            Upload your PDF document and we'll convert it into a beautiful, 
            responsive HTML email template
          </p>
        </div>

        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`drag-area ${
            isDragActive ? 'active' : ''
          } ${isConverting ? 'pointer-events-none opacity-50' : ''}`}
        >
          <input 
            ref={fileInputRef}
            type="file"
            accept=".pdf"
            onChange={handleFileInputChange}
            className="hidden"
          />
          
          {isConverting ? (
            <div className="space-y-4">
              <Loader className="mx-auto h-12 w-12 text-primary-600 animate-spin" />
              <div className="space-y-2">
                <h3 className="text-lg font-semibold text-gray-900">
                  Converting PDF...
                </h3>
                <p className="text-gray-600">
                  Processing your document and extracting content
                </p>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-primary-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
                <p className="text-sm text-gray-500">{uploadProgress}% complete</p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="mx-auto w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center">
                <Upload className="h-8 w-8 text-primary-600" />
              </div>
              
              <div className="space-y-2">
                <h3 className="text-lg font-semibold text-gray-900">
                  {isDragActive ? 'Drop your PDF here' : 'Upload PDF Document'}
                </h3>
                <p className="text-gray-600">
                  Drag and drop your PDF file here, or click to browse
                </p>
              </div>

              <button 
                className="btn-primary"
                onClick={() => fileInputRef.current?.click()}
              >
                Choose PDF File
              </button>
            </div>
          )}
        </div>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <FileText className="h-6 w-6 text-blue-600" />
            </div>
            <h4 className="font-semibold text-gray-900 mb-2">Smart Conversion</h4>
            <p className="text-sm text-gray-600">
              AI-powered PDF analysis extracts text, images, and layout structure
            </p>
          </div>

          <div className="text-center">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
            <h4 className="font-semibold text-gray-900 mb-2">Email Optimized</h4>
            <p className="text-sm text-gray-600">
              Generates email-client compatible HTML with responsive design
            </p>
          </div>

          <div className="text-center">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <AlertCircle className="h-6 w-6 text-purple-600" />
            </div>
            <h4 className="font-semibold text-gray-900 mb-2">Easy Editing</h4>
            <p className="text-sm text-gray-600">
              Drag-and-drop editor to customize your template before export
            </p>
          </div>
        </div>

        <div className="mt-8 bg-gray-50 rounded-lg p-6">
          <h4 className="font-semibold text-gray-900 mb-3">Supported Features</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span>Text extraction and formatting</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span>Image preservation and optimization</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span>Layout structure detection</span>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span>Responsive design generation</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span>Email client compatibility</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span>CSS inlining for better delivery</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default PDFUploader
