import React, { useState } from 'react'
import { Image as ImageIcon, Edit3, Trash2, Upload } from 'lucide-react'

function ImageElement({ element, isSelected, onClick, onUpdate }) {
  const [isEditing, setIsEditing] = useState(false)
  const [imageSrc, setImageSrc] = useState(element.content.src || '')
  const [imageAlt, setImageAlt] = useState(element.content.alt || '')

  const handleSave = () => {
    onUpdate({ 
      content: { 
        src: imageSrc, 
        alt: imageAlt 
      } 
    })
    setIsEditing(false)
  }

  const handleImageUpload = (e) => {
    const file = e.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        setImageSrc(event.target.result)
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <div
      className={`relative group cursor-pointer transition-all duration-200 ${
        isSelected ? 'ring-2 ring-primary-500 ring-offset-2' : 'hover:ring-1 hover:ring-gray-300'
      }`}
      onClick={onClick}
    >
      {isEditing ? (
        <div className="space-y-3 p-3 border border-primary-300 rounded">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Image URL
            </label>
            <input
              type="url"
              value={imageSrc}
              onChange={(e) => setImageSrc(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-primary-500"
              placeholder="https://example.com/image.jpg"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Alt Text
            </label>
            <input
              type="text"
              value={imageAlt}
              onChange={(e) => setImageAlt(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-primary-500"
              placeholder="Describe the image"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Upload Image
            </label>
            <input
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>

          <div className="flex space-x-2">
            <button
              onClick={handleSave}
              className="px-3 py-1 bg-primary-600 text-white text-sm rounded hover:bg-primary-700"
            >
              Save
            </button>
            <button
              onClick={() => {
                setImageSrc(element.content.src || '')
                setImageAlt(element.content.alt || '')
                setIsEditing(false)
              }}
              className="px-3 py-1 bg-gray-300 text-gray-700 text-sm rounded hover:bg-gray-400"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <div className="relative">
          {imageSrc ? (
            <img
              src={imageSrc}
              alt={imageAlt}
              className="w-full h-auto rounded"
              style={element.styles}
            />
          ) : (
            <div
              className="w-full h-32 bg-gray-100 border-2 border-dashed border-gray-300 rounded flex items-center justify-center"
              style={element.styles}
            >
              <div className="text-center text-gray-500">
                <ImageIcon size={24} className="mx-auto mb-2" />
                <p className="text-sm">No image selected</p>
              </div>
            </div>
          )}
        </div>
      )}

      {isSelected && !isEditing && (
        <div className="absolute -top-8 left-0 flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={(e) => {
              e.stopPropagation()
              setIsEditing(true)
            }}
            className="p-1 bg-white border border-gray-300 rounded shadow-sm hover:bg-gray-50"
            title="Edit image"
          >
            <Edit3 size={14} />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation()
              onUpdate({ deleted: true })
            }}
            className="p-1 bg-white border border-gray-300 rounded shadow-sm hover:bg-red-50 hover:border-red-300"
            title="Delete element"
          >
            <Trash2 size={14} />
          </button>
        </div>
      )}
    </div>
  )
}

export default ImageElement
