import React, { useState } from 'react'
import { Edit3, Trash2, ExternalLink } from 'lucide-react'

function ButtonElement({ element, isSelected, onClick, onUpdate }) {
  const [isEditing, setIsEditing] = useState(false)
  const [buttonText, setButtonText] = useState(element.content.text || 'Click Here')
  const [buttonUrl, setButtonUrl] = useState(element.content.url || '#')

  const handleSave = () => {
    onUpdate({ 
      content: { 
        text: buttonText, 
        url: buttonUrl 
      } 
    })
    setIsEditing(false)
  }

  return (
    <div
      className={`relative group cursor-pointer transition-all duration-200 ${
        isSelected ? 'ring-2 ring-primary-500 ring-offset-2' : 'hover:ring-1 hover:ring-gray-300'
      }`}
      onClick={onClick}
    >
      {isEditing ? (
        <div className="space-y-3 p-3 border border-primary-300 rounded">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Button Text
            </label>
            <input
              type="text"
              value={buttonText}
              onChange={(e) => setButtonText(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-primary-500"
              placeholder="Button text"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Button URL
            </label>
            <input
              type="url"
              value={buttonUrl}
              onChange={(e) => setButtonUrl(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-primary-500"
              placeholder="https://example.com"
            />
          </div>

          <div className="flex space-x-2">
            <button
              onClick={handleSave}
              className="px-3 py-1 bg-primary-600 text-white text-sm rounded hover:bg-primary-700"
            >
              Save
            </button>
            <button
              onClick={() => {
                setButtonText(element.content.text || 'Click Here')
                setButtonUrl(element.content.url || '#')
                setIsEditing(false)
              }}
              className="px-3 py-1 bg-gray-300 text-gray-700 text-sm rounded hover:bg-gray-400"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <div className="text-center">
          <a
            href={buttonUrl}
            className="inline-block px-6 py-3 rounded-lg font-medium transition-colors"
            style={element.styles}
            onClick={(e) => e.preventDefault()}
          >
            {buttonText}
          </a>
        </div>
      )}

      {isSelected && !isEditing && (
        <div className="absolute -top-8 left-0 flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={(e) => {
              e.stopPropagation()
              setIsEditing(true)
            }}
            className="p-1 bg-white border border-gray-300 rounded shadow-sm hover:bg-gray-50"
            title="Edit button"
          >
            <Edit3 size={14} />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation()
              onUpdate({ deleted: true })
            }}
            className="p-1 bg-white border border-gray-300 rounded shadow-sm hover:bg-red-50 hover:border-red-300"
            title="Delete element"
          >
            <Trash2 size={14} />
          </button>
        </div>
      )}
    </div>
  )
}

export default ButtonElement
