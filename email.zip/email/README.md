# PDF to Email Builder

A modern, advanced tool for converting PDF documents into beautiful, responsive HTML email templates. Built with React, Node.js, and inspired by the functionality of ecosend.io's email builder.

## Features

### 🚀 Core Functionality
- **PDF to HTML Conversion**: Upload PDF documents and automatically convert them to HTML email templates
- **Drag & Drop Builder**: Intuitive interface for building email templates with drag-and-drop elements
- **Real-time Preview**: See your email template as you build it with live preview
- **Responsive Design**: Automatically generates mobile-friendly email templates
- **CSS Inlining**: Inline CSS for maximum email client compatibility

### 🎨 Email Elements
- **Text Blocks**: Rich text editing with formatting options
- **Images**: Upload and manage images with alt text support
- **Buttons**: Call-to-action buttons with customizable styling
- **Dividers**: Horizontal lines with various styles and colors
- **Spacers**: Add vertical spacing between elements
- **Links**: Text links with URL management

### 🛠️ Advanced Features
- **Properties Panel**: Detailed editing of element properties and styles
- **Template Customization**: Adjust colors, fonts, and layout settings
- **Export Options**: Download HTML, copy to clipboard, or export to email platforms
- **Email Client Compatibility**: Optimized for major email clients
- **Modern UI**: Clean, professional interface with dark/light themes

## Installation

### Prerequisites
- Node.js (v16 or higher)
- npm or yarn

### Setup

1. **Clone or download the project**
   ```bash
   cd /Users/578294/Desktop/email
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm run dev
   ```

4. **Start the backend server** (in a new terminal)
   ```bash
   npm start
   ```

5. **Open your browser**
   Navigate to `http://localhost:3000`

## Usage

### Converting PDF to Email Template

1. **Upload PDF**: Click on the upload area or drag and drop your PDF file
2. **Automatic Conversion**: The system will analyze and convert your PDF content
3. **Review Generated Template**: Check the automatically generated HTML structure
4. **Customize**: Use the drag-and-drop builder to modify the template

### Building Email Templates

1. **Add Elements**: Drag elements from the sidebar to the canvas
2. **Edit Properties**: Click on elements to edit their content and styles
3. **Customize Layout**: Adjust spacing, colors, and typography
4. **Preview**: Use the preview modes to see how your email looks on different devices
5. **Export**: Download your finished template or copy the HTML code

### Supported File Formats
- **Input**: PDF documents (up to 10MB)
- **Output**: HTML email templates, inline CSS

## API Endpoints

### POST `/api/convert-pdf`
Convert a PDF file to HTML email template
- **Body**: FormData with PDF file
- **Response**: JSON with HTML content and metadata

### POST `/api/inline-css`
Inline CSS styles for email compatibility
- **Body**: `{ html: string }`
- **Response**: JSON with inlined HTML

### POST `/api/export-html`
Export HTML template as downloadable file
- **Body**: `{ html: string, filename?: string }`
- **Response**: HTML file download

## Project Structure

```
pdf-to-email-builder/
├── src/
│   ├── components/
│   │   ├── elements/          # Email element components
│   │   ├── Header.jsx         # Main header component
│   │   ├── Sidebar.jsx        # Navigation sidebar
│   │   ├── MainCanvas.jsx     # Main canvas area
│   │   ├── EmailCanvas.jsx    # Email template canvas
│   │   ├── PDFUploader.jsx    # PDF upload component
│   │   └── PropertiesPanel.jsx # Element properties panel
│   ├── context/
│   │   └── EmailContext.jsx   # React context for state management
│   ├── App.jsx                # Main app component
│   ├── main.jsx              # React entry point
│   └── index.css             # Global styles
├── server.js                 # Express backend server
├── package.json              # Dependencies and scripts
└── README.md                 # This file
```

## Technologies Used

### Frontend
- **React 18**: Modern React with hooks and context
- **Tailwind CSS**: Utility-first CSS framework
- **React DnD**: Drag and drop functionality
- **Lucide React**: Beautiful icons
- **React Toastify**: Toast notifications

### Backend
- **Express.js**: Node.js web framework
- **Multer**: File upload handling
- **PDF-Parse**: PDF text extraction
- **Cheerio**: HTML parsing and manipulation
- **Juice**: CSS inlining for email compatibility

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

MIT License - see LICENSE file for details

## Support

For issues and questions:
1. Check the documentation
2. Search existing issues
3. Create a new issue with detailed information

## Roadmap

- [ ] Advanced PDF layout detection
- [ ] More email element types
- [ ] Template library
- [ ] Email testing tools
- [ ] Integration with email marketing platforms
- [ ] Batch PDF processing
- [ ] Advanced styling options
- [ ] Email analytics integration

---

Built with ❤️ for modern email marketing needs.
