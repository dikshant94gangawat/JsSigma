import React from 'react'
import { 
  Menu, 
  X, 
  Settings, 
  Download, 
  Eye, 
  Smartphone, 
  Monitor,
  Tablet
} from 'lucide-react'

function Header({ 
  activeTab, 
  setActiveTab, 
  sidebarOpen, 
  setSidebarOpen,
  propertiesOpen,
  setPropertiesOpen 
}) {
  return (
    <header className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
      <div className="flex items-center space-x-4">
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
        
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-gradient-to-r from-primary-500 to-primary-600 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-sm">E</span>
          </div>
          <h1 className="text-xl font-semibold text-gray-900">
            PDF to Email Builder
          </h1>
        </div>
      </div>

      <div className="flex items-center space-x-4">
        {activeTab === 'builder' && (
          <>
            <div className="flex items-center space-x-2 bg-gray-100 rounded-lg p-1">
              <button
                className={`p-2 rounded-md transition-colors ${
                  activeTab === 'desktop' ? 'bg-white shadow-sm' : 'hover:bg-gray-200'
                }`}
                title="Desktop Preview"
              >
                <Monitor size={16} />
              </button>
              <button
                className={`p-2 rounded-md transition-colors ${
                  activeTab === 'tablet' ? 'bg-white shadow-sm' : 'hover:bg-gray-200'
                }`}
                title="Tablet Preview"
              >
                <Tablet size={16} />
              </button>
              <button
                className={`p-2 rounded-md transition-colors ${
                  activeTab === 'mobile' ? 'bg-white shadow-sm' : 'hover:bg-gray-200'
                }`}
                title="Mobile Preview"
              >
                <Smartphone size={16} />
              </button>
            </div>

            <button
              onClick={() => setPropertiesOpen(!propertiesOpen)}
              className={`p-2 rounded-lg transition-colors ${
                propertiesOpen ? 'bg-primary-100 text-primary-600' : 'hover:bg-gray-100'
              }`}
              title="Properties Panel"
            >
              <Settings size={20} />
            </button>

            <button
              className="btn-primary flex items-center space-x-2"
              title="Preview Email"
            >
              <Eye size={16} />
              <span>Preview</span>
            </button>

            <button
              className="btn-primary flex items-center space-x-2"
              title="Export HTML"
            >
              <Download size={16} />
              <span>Export</span>
            </button>
          </>
        )}
      </div>
    </header>
  )
}

export default Header
