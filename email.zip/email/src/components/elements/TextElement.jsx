import React, { useState } from 'react'
import { Edit3, Trash2 } from 'lucide-react'

function TextElement({ element, isSelected, onClick, onUpdate }) {
  const [isEditing, setIsEditing] = useState(false)
  const [content, setContent] = useState(element.content)

  const handleSave = () => {
    onUpdate({ content })
    setIsEditing(false)
  }

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      handleSave()
    }
  }

  return (
    <div
      className={`relative group cursor-pointer transition-all duration-200 ${
        isSelected ? 'ring-2 ring-primary-500 ring-offset-2' : 'hover:ring-1 hover:ring-gray-300'
      }`}
      onClick={onClick}
    >
      {isEditing ? (
        <div className="space-y-2">
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            onKeyDown={handleKeyPress}
            className="w-full p-2 border border-primary-300 rounded focus:outline-none focus:ring-2 focus:ring-primary-500"
            style={element.styles}
            autoFocus
            rows={3}
          />
          <div className="flex space-x-2">
            <button
              onClick={handleSave}
              className="px-3 py-1 bg-primary-600 text-white text-sm rounded hover:bg-primary-700"
            >
              Save
            </button>
            <button
              onClick={() => {
                setContent(element.content)
                setIsEditing(false)
              }}
              className="px-3 py-1 bg-gray-300 text-gray-700 text-sm rounded hover:bg-gray-400"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <div
          className="p-2 min-h-[2rem]"
          style={element.styles}
          dangerouslySetInnerHTML={{ __html: content.replace(/\n/g, '<br>') }}
        />
      )}

      {isSelected && !isEditing && (
        <div className="absolute -top-8 left-0 flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={(e) => {
              e.stopPropagation()
              setIsEditing(true)
            }}
            className="p-1 bg-white border border-gray-300 rounded shadow-sm hover:bg-gray-50"
            title="Edit text"
          >
            <Edit3 size={14} />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation()
              onUpdate({ deleted: true })
            }}
            className="p-1 bg-white border border-gray-300 rounded shadow-sm hover:bg-red-50 hover:border-red-300"
            title="Delete element"
          >
            <Trash2 size={14} />
          </button>
        </div>
      )}
    </div>
  )
}

export default TextElement
