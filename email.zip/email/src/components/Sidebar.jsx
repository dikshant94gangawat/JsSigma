import React from 'react'
import { 
  Upload, 
  Layout, 
  Type, 
  Image, 
  Square, 
  Link,
  Palette,
  Code,
  FileText
} from 'lucide-react'

function Sidebar({ activeTab, setActiveTab, onAddElement }) {
  const tabs = [
    { id: 'upload', label: 'Upload PDF', icon: Upload },
    { id: 'builder', label: 'Email Builder', icon: Layout },
    { id: 'elements', label: 'Elements', icon: Square },
    { id: 'styles', label: 'Styles', icon: Palette },
    { id: 'code', label: 'Code', icon: Code },
    { id: 'export', label: 'Export', icon: FileText }
  ]

  const elements = [
    { type: 'text', label: 'Text Block', icon: Type, description: 'Add text content' },
    { type: 'image', label: 'Image', icon: Image, description: 'Add images' },
    { type: 'button', label: 'Button', icon: Square, description: 'Call-to-action button' },
    { type: 'divider', label: 'Divider', icon: Square, description: 'Horizontal line' },
    { type: 'spacer', label: 'Spacer', icon: Square, description: 'Add spacing' },
    { type: 'link', label: 'Link', icon: Link, description: 'Text link' }
  ]

  return (
    <aside className="w-80 bg-white border-r border-gray-200 flex flex-col">
      <div className="p-4 border-b border-gray-200">
        <nav className="flex space-x-1">
          {tabs.map(tab => {
            const Icon = tab.icon
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 flex items-center justify-center space-x-2 py-2 px-3 rounded-lg text-sm font-medium transition-colors ${
                  activeTab === tab.id
                    ? 'bg-primary-100 text-primary-700'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <Icon size={16} />
                <span className="hidden sm:inline">{tab.label}</span>
              </button>
            )
          })}
        </nav>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === 'upload' && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900">Upload PDF</h3>
            <p className="text-sm text-gray-600">
              Upload a PDF document to convert it into an HTML email template.
            </p>
            <div className="space-y-3">
              <div className="text-sm text-gray-500">
                <strong>Supported formats:</strong> PDF
              </div>
              <div className="text-sm text-gray-500">
                <strong>Max file size:</strong> 10MB
              </div>
              <div className="text-sm text-gray-500">
                <strong>Features:</strong>
                <ul className="mt-1 space-y-1 ml-4">
                  <li>• Automatic layout detection</li>
                  <li>• Text extraction</li>
                  <li>• Image preservation</li>
                  <li>• Responsive conversion</li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'elements' && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900">Email Elements</h3>
            <p className="text-sm text-gray-600">
              Drag and drop elements to build your email template.
            </p>
            <div className="grid grid-cols-1 gap-3">
              {elements.map(element => {
                const Icon = element.icon
                return (
                  <div
                    key={element.type}
                    className="p-3 border border-gray-200 rounded-lg hover:border-primary-300 hover:bg-primary-50 cursor-pointer transition-colors group"
                    onClick={() => onAddElement && onAddElement(element.type)}
                  >
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-gray-100 rounded-lg group-hover:bg-primary-100 transition-colors">
                        <Icon size={16} className="text-gray-600 group-hover:text-primary-600" />
                      </div>
                      <div className="flex-1">
                        <div className="font-medium text-gray-900">{element.label}</div>
                        <div className="text-sm text-gray-500">{element.description}</div>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {activeTab === 'styles' && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900">Styles & Themes</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Color Scheme
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#6b7280', '#000000'].map(color => (
                    <button
                      key={color}
                      className="w-8 h-8 rounded-lg border-2 border-gray-200 hover:border-gray-300 transition-colors"
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Font Family
                </label>
                <select className="input-field">
                  <option value="Arial">Arial</option>
                  <option value="Helvetica">Helvetica</option>
                  <option value="Georgia">Georgia</option>
                  <option value="Times New Roman">Times New Roman</option>
                  <option value="Verdana">Verdana</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Template Width
                </label>
                <input
                  type="range"
                  min="300"
                  max="800"
                  defaultValue="600"
                  className="w-full"
                />
                <div className="text-sm text-gray-500 mt-1">600px</div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'code' && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900">Generated Code</h3>
            <div className="space-y-3">
              <button className="w-full btn-outline text-sm">
                View HTML
              </button>
              <button className="w-full btn-outline text-sm">
                View CSS
              </button>
              <button className="w-full btn-outline text-sm">
                Inline CSS
              </button>
            </div>
            <div className="bg-gray-100 rounded-lg p-3">
              <div className="text-sm text-gray-600">
                <strong>Code Features:</strong>
                <ul className="mt-1 space-y-1 ml-4">
                  <li>• Email-client compatible</li>
                  <li>• Responsive design</li>
                  <li>• Inline CSS support</li>
                  <li>• Clean, semantic HTML</li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'export' && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900">Export Options</h3>
            <div className="space-y-3">
              <button className="w-full btn-primary">
                Download HTML
              </button>
              <button className="w-full btn-outline">
                Copy to Clipboard
              </button>
              <button className="w-full btn-outline">
                Export to Mailchimp
              </button>
              <button className="w-full btn-outline">
                Export to Constant Contact
              </button>
            </div>
            <div className="bg-gray-100 rounded-lg p-3">
              <div className="text-sm text-gray-600">
                <strong>Export includes:</strong>
                <ul className="mt-1 space-y-1 ml-4">
                  <li>• Complete HTML template</li>
                  <li>• Inline CSS styles</li>
                  <li>• Responsive meta tags</li>
                  <li>• Email client compatibility</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>
    </aside>
  )
}

export default Sidebar
