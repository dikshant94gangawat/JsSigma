import React from 'react'
import { useEmail } from '../context/EmailContext'
import { Palette, Type, Layout, Image } from 'lucide-react'

function PropertiesPanel() {
  const { emailTemplate, selectedElement, dispatch } = useEmail()

  const selectedElementData = emailTemplate.elements.find(el => el.id === selectedElement)

  const updateTemplateProperty = (property, value) => {
    dispatch({
      type: 'UPDATE_TEMPLATE',
      payload: { [property]: value }
    })
  }

  const updateElementProperty = (property, value) => {
    dispatch({
      type: 'UPDATE_ELEMENT',
      payload: { id: selectedElement, [property]: value }
    })
  }

  const updateElementStyle = (styleProperty, value) => {
    const updatedStyles = {
      ...selectedElementData.styles,
      [styleProperty]: value
    }
    updateElementProperty('styles', updatedStyles)
  }

  return (
    <div className="w-80 bg-white border-l border-gray-200 flex flex-col">
      <div className="p-4 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900">Properties</h3>
        <p className="text-sm text-gray-600">
          {selectedElementData ? `Edit ${selectedElementData.type} element` : 'Select an element to edit its properties'}
        </p>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {!selectedElementData ? (
          <div className="text-center py-8 text-gray-500">
            <Layout className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <p>No element selected</p>
            <p className="text-sm">Click on an element in the canvas to edit its properties</p>
          </div>
        ) : (
          <>
            {/* Element Type Header */}
            <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
              {selectedElementData.type === 'text' && <Type className="h-5 w-5 text-blue-600" />}
              {selectedElementData.type === 'image' && <Image className="h-5 w-5 text-green-600" />}
              {selectedElementData.type === 'button' && <div className="w-5 h-5 bg-primary-600 rounded" />}
              {selectedElementData.type === 'divider' && <div className="w-5 h-0.5 bg-gray-400" />}
              {selectedElementData.type === 'spacer' && <div className="w-5 h-5 border-2 border-dashed border-gray-400" />}
              {selectedElementData.type === 'link' && <div className="w-5 h-5 text-blue-600">🔗</div>}
              <div>
                <h4 className="font-medium text-gray-900 capitalize">{selectedElementData.type} Element</h4>
                <p className="text-sm text-gray-500">ID: {selectedElementData.id}</p>
              </div>
            </div>

            {/* Content Properties */}
            <div>
              <h4 className="font-medium text-gray-900 mb-3 flex items-center space-x-2">
                <Type size={16} />
                <span>Content</span>
              </h4>
              <div className="space-y-3">
                {selectedElementData.type === 'text' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Text Content
                    </label>
                    <textarea
                      value={selectedElementData.content}
                      onChange={(e) => updateElementProperty('content', e.target.value)}
                      className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-primary-500"
                      rows={3}
                    />
                  </div>
                )}

                {selectedElementData.type === 'image' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Image URL
                      </label>
                      <input
                        type="url"
                        value={selectedElementData.content.src || ''}
                        onChange={(e) => updateElementProperty('content', {
                          ...selectedElementData.content,
                          src: e.target.value
                        })}
                        className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-primary-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Alt Text
                      </label>
                      <input
                        type="text"
                        value={selectedElementData.content.alt || ''}
                        onChange={(e) => updateElementProperty('content', {
                          ...selectedElementData.content,
                          alt: e.target.value
                        })}
                        className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-primary-500"
                      />
                    </div>
                  </>
                )}

                {selectedElementData.type === 'button' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Button Text
                      </label>
                      <input
                        type="text"
                        value={selectedElementData.content.text || ''}
                        onChange={(e) => updateElementProperty('content', {
                          ...selectedElementData.content,
                          text: e.target.value
                        })}
                        className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-primary-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Button URL
                      </label>
                      <input
                        type="url"
                        value={selectedElementData.content.url || ''}
                        onChange={(e) => updateElementProperty('content', {
                          ...selectedElementData.content,
                          url: e.target.value
                        })}
                        className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-primary-500"
                      />
                    </div>
                  </>
                )}

                {selectedElementData.type === 'link' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Link Text
                      </label>
                      <input
                        type="text"
                        value={selectedElementData.content.text || ''}
                        onChange={(e) => updateElementProperty('content', {
                          ...selectedElementData.content,
                          text: e.target.value
                        })}
                        className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-primary-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Link URL
                      </label>
                      <input
                        type="url"
                        value={selectedElementData.content.url || ''}
                        onChange={(e) => updateElementProperty('content', {
                          ...selectedElementData.content,
                          url: e.target.value
                        })}
                        className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-primary-500"
                      />
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Style Properties */}
            <div>
              <h4 className="font-medium text-gray-900 mb-3 flex items-center space-x-2">
                <Palette size={16} />
                <span>Styles</span>
              </h4>
              <div className="space-y-3">
                {/* Text Styles */}
                {(selectedElementData.type === 'text' || selectedElementData.type === 'button' || selectedElementData.type === 'link') && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Font Size
                      </label>
                      <input
                        type="number"
                        value={parseInt(selectedElementData.styles.fontSize) || 16}
                        onChange={(e) => updateElementStyle('fontSize', `${e.target.value}px`)}
                        className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-primary-500"
                        min="8"
                        max="72"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Font Family
                      </label>
                      <select
                        value={selectedElementData.styles.fontFamily || 'Arial, sans-serif'}
                        onChange={(e) => updateElementStyle('fontFamily', e.target.value)}
                        className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-primary-500"
                      >
                        <option value="Arial, sans-serif">Arial</option>
                        <option value="Helvetica, sans-serif">Helvetica</option>
                        <option value="Georgia, serif">Georgia</option>
                        <option value="Times New Roman, serif">Times New Roman</option>
                        <option value="Verdana, sans-serif">Verdana</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Text Color
                      </label>
                      <input
                        type="color"
                        value={selectedElementData.styles.color || '#374151'}
                        onChange={(e) => updateElementStyle('color', e.target.value)}
                        className="w-full h-10 border border-gray-300 rounded cursor-pointer"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Text Align
                      </label>
                      <select
                        value={selectedElementData.styles.textAlign || 'left'}
                        onChange={(e) => updateElementStyle('textAlign', e.target.value)}
                        className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-primary-500"
                      >
                        <option value="left">Left</option>
                        <option value="center">Center</option>
                        <option value="right">Right</option>
                        <option value="justify">Justify</option>
                      </select>
                    </div>
                  </>
                )}

                {/* Background Color */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Background Color
                  </label>
                  <input
                    type="color"
                    value={selectedElementData.styles.backgroundColor || '#ffffff'}
                    onChange={(e) => updateElementStyle('backgroundColor', e.target.value)}
                    className="w-full h-10 border border-gray-300 rounded cursor-pointer"
                  />
                </div>

                {/* Padding */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Padding
                  </label>
                  <input
                    type="number"
                    value={parseInt(selectedElementData.styles.padding) || 10}
                    onChange={(e) => updateElementStyle('padding', `${e.target.value}px`)}
                    className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-primary-500"
                    min="0"
                    max="50"
                  />
                </div>

                {/* Margin */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Margin
                  </label>
                  <input
                    type="number"
                    value={parseInt(selectedElementData.styles.margin) || 0}
                    onChange={(e) => updateElementStyle('margin', `${e.target.value}px`)}
                    className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-primary-500"
                    min="0"
                    max="50"
                  />
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-4 border-t border-gray-200">
              <button
                onClick={() => dispatch({ type: 'REMOVE_ELEMENT', payload: selectedElement })}
                className="w-full px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              >
                Delete Element
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  )
}

export default PropertiesPanel
