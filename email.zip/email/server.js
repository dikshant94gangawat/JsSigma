const express = require('express')
const multer = require('multer')
const cors = require('cors')
const path = require('path')
const fs = require('fs')
const pdfParse = require('pdf-parse')
const cheerio = require('cheerio')
const juice = require('juice')

const app = express()
const PORT = process.env.PORT || 5000

// Middleware
app.use(cors())
app.use(express.json())
app.use(express.static('dist'))

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = 'uploads'
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir)
    }
    cb(null, uploadDir)
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname)
  }
})

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf') {
      cb(null, true)
    } else {
      cb(new Error('Only PDF files are allowed'), false)
    }
  }
})

// PDF to HTML conversion endpoint
app.post('/api/convert-pdf', upload.single('pdf'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No PDF file uploaded' })
    }

    const pdfPath = req.file.path
    
    // Read PDF file
    const pdfBuffer = fs.readFileSync(pdfPath)
    const pdfData = await pdfParse(pdfBuffer)
    
    // Extract text content
    const textContent = pdfData.text
    
    // Generate HTML structure
    const html = generateEmailHTML(textContent, pdfData)
    
    // Clean up uploaded file
    fs.unlinkSync(pdfPath)
    
    res.json({
      success: true,
      html: html,
      pages: [{
        pageNumber: 1,
        content: textContent,
        html: html
      }],
      metadata: {
        pages: pdfData.numpages,
        info: pdfData.info
      }
    })
    
  } catch (error) {
    console.error('PDF conversion error:', error)
    res.status(500).json({ 
      error: 'Failed to convert PDF',
      details: error.message 
    })
  }
})

// CSS Inlining endpoint
app.post('/api/inline-css', (req, res) => {
  try {
    const { html } = req.body
    
    if (!html) {
      return res.status(400).json({ error: 'HTML content is required' })
    }
    
    // Inline CSS using juice
    const inlinedHTML = juice(html, {
      removeStyleTags: true,
      preserveMediaQueries: true,
      preserveKeyFrames: true,
      insertPreservedExtraCss: true,
      webResources: {
        relativeTo: __dirname
      }
    })
    
    res.json({
      success: true,
      html: inlinedHTML
    })
    
  } catch (error) {
    console.error('CSS inlining error:', error)
    res.status(500).json({ 
      error: 'Failed to inline CSS',
      details: error.message 
    })
  }
})

// Export HTML endpoint
app.post('/api/export-html', (req, res) => {
  try {
    const { html, filename = 'email-template.html' } = req.body
    
    if (!html) {
      return res.status(400).json({ error: 'HTML content is required' })
    }
    
    // Set headers for file download
    res.setHeader('Content-Type', 'text/html')
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`)
    
    res.send(html)
    
  } catch (error) {
    console.error('Export error:', error)
    res.status(500).json({ 
      error: 'Failed to export HTML',
      details: error.message 
    })
  }
})

// Generate email HTML from PDF content
function generateEmailHTML(textContent, pdfData) {
  const $ = cheerio.load('')
  
  // Create email structure
  const emailHTML = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Email Template</title>
      <style>
        body {
          margin: 0;
          padding: 0;
          font-family: Arial, sans-serif;
          line-height: 1.6;
          color: #333;
        }
        .email-container {
          max-width: 600px;
          margin: 0 auto;
          background-color: #ffffff;
        }
        .email-header {
          background-color: #f8f9fa;
          padding: 20px;
          text-align: center;
          border-bottom: 1px solid #e9ecef;
        }
        .email-content {
          padding: 30px 20px;
        }
        .email-footer {
          background-color: #f8f9fa;
          padding: 20px;
          text-align: center;
          border-top: 1px solid #e9ecef;
          font-size: 12px;
          color: #6c757d;
        }
        .content-block {
          margin-bottom: 20px;
        }
        .content-block h1, .content-block h2, .content-block h3 {
          color: #2c3e50;
          margin-top: 0;
        }
        .content-block p {
          margin-bottom: 15px;
        }
        .button {
          display: inline-block;
          background-color: #007bff;
          color: white;
          padding: 12px 24px;
          text-decoration: none;
          border-radius: 5px;
          margin: 10px 0;
        }
        .button:hover {
          background-color: #0056b3;
        }
        @media only screen and (max-width: 600px) {
          .email-container {
            width: 100% !important;
          }
          .email-content {
            padding: 20px 15px;
          }
        }
      </style>
    </head>
    <body>
      <div class="email-container">
        <div class="email-header">
          <h1>Your Email Template</h1>
        </div>
        <div class="email-content">
          ${processTextContent(textContent)}
        </div>
        <div class="email-footer">
          <p>This email was generated from a PDF document</p>
        </div>
      </div>
    </body>
    </html>
  `
  
  return emailHTML
}

// Process text content and convert to HTML
function processTextContent(text) {
  if (!text) return '<p>No content available</p>'
  
  // Split text into paragraphs
  const paragraphs = text.split('\n\n').filter(p => p.trim().length > 0)
  
  let html = ''
  
  paragraphs.forEach(paragraph => {
    const trimmedParagraph = paragraph.trim()
    
    if (trimmedParagraph.length === 0) return
    
    // Check if it looks like a heading (short, no periods, all caps or title case)
    if (trimmedParagraph.length < 100 && 
        !trimmedParagraph.includes('.') && 
        (trimmedParagraph === trimmedParagraph.toUpperCase() || 
         isTitleCase(trimmedParagraph))) {
      html += `<h2 class="content-block">${trimmedParagraph}</h2>\n`
    } else {
      // Regular paragraph
      html += `<div class="content-block"><p>${trimmedParagraph}</p></div>\n`
    }
  })
  
  // Add a call-to-action button if content is substantial
  if (text.length > 200) {
    html += `
      <div class="content-block" style="text-align: center; margin-top: 30px;">
        <a href="#" class="button">Learn More</a>
      </div>
    `
  }
  
  return html
}

// Helper function to check if text is title case
function isTitleCase(text) {
  const words = text.split(' ')
  return words.every(word => 
    word.length === 0 || 
    word[0] === word[0].toUpperCase()
  )
}

// Serve React app for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'))
})

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
  console.log(`PDF to Email Builder is ready!`)
})
