import React, { useEffect } from 'react'
import PDFUploader from './PDFUploader'
import EmailCanvas from './EmailCanvas'
import { useEmail } from '../context/EmailContext'

function MainCanvas({ activeTab, setActiveTab }) {
  const { emailTemplate, dispatch } = useEmail()

  // Listen for tab switch events from PDFUploader
  useEffect(() => {
    const handleTabSwitch = (event) => {
      setActiveTab(event.detail)
    }
    
    window.addEventListener('switchTab', handleTabSwitch)
    return () => window.removeEventListener('switchTab', handleTabSwitch)
  }, [setActiveTab])

  const handleAddElement = (elementType) => {
    const newElement = {
      id: Date.now().toString(),
      type: elementType,
      content: getDefaultContent(elementType),
      styles: getDefaultStyles(elementType),
      position: { x: 0, y: 0 }
    }
    
    dispatch({ type: 'ADD_ELEMENT', payload: newElement })
  }

  const getDefaultContent = (type) => {
    switch (type) {
      case 'text':
        return 'Your text content here'
      case 'image':
        return { src: '', alt: 'Image' }
      case 'button':
        return { text: 'Click Here', url: '#' }
      case 'divider':
        return { style: 'solid', color: '#e5e7eb' }
      case 'spacer':
        return { height: 20 }
      case 'link':
        return { text: 'Link text', url: '#' }
      default:
        return ''
    }
  }

  const getDefaultStyles = (type) => {
    const baseStyles = {
      margin: '0',
      padding: '10px',
      textAlign: 'left'
    }

    switch (type) {
      case 'text':
        return {
          ...baseStyles,
          fontSize: '16px',
          color: '#374151',
          fontFamily: 'Arial, sans-serif'
        }
      case 'image':
        return {
          ...baseStyles,
          maxWidth: '100%',
          height: 'auto'
        }
      case 'button':
        return {
          ...baseStyles,
          backgroundColor: '#3b82f6',
          color: '#ffffff',
          padding: '12px 24px',
          borderRadius: '6px',
          textDecoration: 'none',
          display: 'inline-block',
          fontSize: '16px',
          fontWeight: '500'
        }
      case 'divider':
        return {
          ...baseStyles,
          height: '1px',
          backgroundColor: '#e5e7eb',
          border: 'none',
          margin: '20px 0'
        }
      case 'spacer':
        return {
          ...baseStyles,
          height: '20px',
          backgroundColor: 'transparent'
        }
      case 'link':
        return {
          ...baseStyles,
          color: '#3b82f6',
          textDecoration: 'underline'
        }
      default:
        return baseStyles
    }
  }

  if (activeTab === 'upload') {
    return <PDFUploader />
  }

  return (
    <div className="flex-1 flex flex-col">
      <div className="flex-1 flex items-center justify-center p-8 bg-gray-50">
        <div className="w-full max-w-4xl">
          <EmailCanvas onAddElement={handleAddElement} />
        </div>
      </div>
    </div>
  )
}

export default MainCanvas
